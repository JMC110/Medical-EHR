# Python program to get a set of
# places according to your search
# query using Google Places API

# importing required modules
import requests, json



f= open('add.txt',"r")
data=f.read()
print(data)



# enter your api key here
#api_key = '50da910610a2cd948baa90829e2def8f66528cbd'
api_key = 'AIzaSyCocen7h-ZgXYnBGPfwhqJcfPj8HuCAOPo'
# url variable store url
url = "https://maps.googleapis.com/maps/api/place/textsearch/json?"

# The text string on which to search
#query = input('Search query: ')
query = data
#print(type(query))
#query = input(data)

# get method of requests module
# return response object
r = requests.get(url + 'query=' + query +'&key=' + api_key)

# json method of response object convert
#  json format data into python format data
x = r.json()

# now x contains list of nested dictionaries
# we know dictionary contain key value pair
# store the value of result key in variable y
y = x['results']
#print(y)
#print('!!!!!!!!!!!!')
#print(type(y))
#y_format = (formatted_address)

#print(y_format)
# keep looping upto length of y
#for i in range(len(y)):
with open ('address.txt','w') as f:
    for i in range(len(y)):
#        print('test1')
        print((y[i]['formatted_address']))
#        print('test2')
        f.write(y[i]['formatted_address'])
#        print('test3')
#    print('test4')
    # Print value corresponding to the
    # 'name' key at the ith index of y
    #print(y[i]['name'])
    #print('test1')

#print('test2')
